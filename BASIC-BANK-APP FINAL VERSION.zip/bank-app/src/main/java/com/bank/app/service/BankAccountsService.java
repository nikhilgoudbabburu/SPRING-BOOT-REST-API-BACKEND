package com.bank.app.service;


import java.util.List;

import com.bank.app.dto.BankAccountsDto;
import com.bank.app.dto.CheckBalanceDto;

public interface BankAccountsService {

	int openAccount(BankAccountsDto bank);

	

	CheckBalanceDto checkBalanceDto(String acNum);

	List<BankAccountsDto> balanceabove(String balance);

}
