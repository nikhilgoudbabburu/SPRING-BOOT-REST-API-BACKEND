
package com.bank.app.domain;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Entity
public class BankAccounts {

	

    @Id // primary key
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long userId; // user_id

    @Column(nullable = false)
    private String acName; // ac_nm

    @Column(unique = true, nullable = false)
    private String acNum; // ac_num

    @Column
    private LocalDate created; // created
    
    @Column
    private double balance;
}