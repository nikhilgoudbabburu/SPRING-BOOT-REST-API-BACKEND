package com.bank.app.service;

import java.util.List;

import com.bank.app.dto.TransactionTypeWiseDto;

public interface BankStatementService {

	int transactionCheck(int txnType, String acNum, double amount, String date);

	int moneyTransfer(int transfer, String sender, String receiver,double amount, String date);

	List<TransactionTypeWiseDto> transactiontypewise(String acNum);

	

}
