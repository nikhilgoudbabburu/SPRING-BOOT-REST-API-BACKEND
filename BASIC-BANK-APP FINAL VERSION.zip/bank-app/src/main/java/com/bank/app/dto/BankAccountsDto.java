package com.bank.app.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class BankAccountsDto {

		 long userId; // user_id
	     String acName; // ac_nm
	     String acNum; // ac_num
	     LocalDate created; // created
	     double balance;
}
