package com.bank.app.serviceimpl;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bank.app.domain.BankAccounts;
import com.bank.app.domain.BankStatement;
import com.bank.app.dto.TransactionTypeWiseDto;
import com.bank.app.repository.BankAccountsRepository;
import com.bank.app.repository.BankStatementRepository;
import com.bank.app.service.BankStatementService;


@Service
public class BankStatementServiceImpl implements BankStatementService {

	@Autowired
	BankStatementRepository repository;
	
	@Autowired
	BankAccountsRepository repositoryBA;
	
	//DEPOSIT AND WITHDRAW
	 @Transactional(rollbackFor = SQLException.class)
	@Override
	public int transactionCheck(int txnType, String acNum, double amount, String date) {
		// TODO Auto-generated method stub
		
		if(txnType == 1) {
		
			BankAccounts bank = repositoryBA.findByAcNum(acNum); 
			if(!bank.getAcNum().isEmpty()) {
				
				BankStatement st = new BankStatement();
				double balance = bank.getBalance() + amount;
				
				System.out.println("deposit started");
				repositoryBA.updateDeposit(amount,acNum);
				
				st.setSName(bank.getAcName());
				st.setSNum(acNum);
				st.setAmount(amount);
				st.setSBalance(balance);
				st.setTxnDate(LocalDate.now());
				st.setTxnType(1);
				
				
				
				repository.save(st);
				System.out.println("deposit ended");
				return 1;
			}
			
		}
		else if(txnType == 2) {
			
			BankAccounts bank = repositoryBA.findByAcNum(acNum); 
			if(!bank.getAcNum().isEmpty()) {
				
				BankStatement st = new BankStatement();
				double balance = bank.getBalance() - amount;
				
				repositoryBA.updateWithdraw(amount,acNum);
				
				st.setSName(bank.getAcName());
				st.setSNum(acNum);
				st.setAmount(amount);
				st.setSBalance(balance);
				st.setTxnDate(LocalDate.now());
				st.setTxnType(2);
				
				repository.save(st);
				return 1;
		}
		
		
	}
		return 0;

	

}
	 
	 //MONEY TRANSFER

	 @Transactional(rollbackFor = SQLException.class)
	@Override
	public int moneyTransfer(int transfer, String sender, String receiver,double amount, String date) {
		// TODO Auto-generated method stub
		BankAccounts bankSender = repositoryBA.findByAcNum(sender);
		BankAccounts bankReceiver = repositoryBA.findByAcNum(receiver);
		
		if(!bankSender.getAcNum().isEmpty() && !bankReceiver.getAcNum().isEmpty()){
			
			if(bankSender.getBalance()>=amount) {
				//sender details
				BankStatement senderSt = new BankStatement();
				double senderBalance = bankSender.getBalance() - amount;
				
				repositoryBA.updateWithdraw(amount,sender);
				
				senderSt.setSName(bankSender.getAcName());
				senderSt.setSNum(sender);
				senderSt.setAmount(amount);
				senderSt.setSBalance(senderBalance);
				senderSt.setTxnDate(LocalDate.now());
				senderSt.setTxnType(3);
				
				repository.save(senderSt);
				
				//sender details
				
				//receiver details
				
				BankStatement receiverSt = new BankStatement();
				double receiverBalance = bankReceiver.getBalance() + amount;
				
				System.out.println("deposit started");
				repositoryBA.updateDeposit(amount,receiver);
				
				receiverSt.setSName(bankReceiver.getAcName());
				receiverSt.setSNum(receiver);
				receiverSt.setAmount(amount);
				receiverSt.setSBalance(receiverBalance);
				receiverSt.setTxnDate(LocalDate.now());
				receiverSt.setTxnType(1);
				
				repository.save(receiverSt);
			

				
				//receiver details
				return 1;
			}
			
		}
		
		
		return 0;
	}


	 
	 //TRANSACTIONTYPE WISE
	 @Transactional(rollbackFor = SQLException.class)
	 @Override
		public List<TransactionTypeWiseDto> transactiontypewise(String acNum) {
			// TODO Auto-generated method stub
		 List<Object[]> bank = repository.transactiontypeWise(acNum);
		 
		 List<TransactionTypeWiseDto> dto = new ArrayList<>();
		 
		 for(int i = 0;i<bank.size();i++) {
			 
			 Object[] b = bank.get(i);
			 
			 TransactionTypeWiseDto d = new TransactionTypeWiseDto();
			
			 d.setAmount((Double)b[0]);
			 d.setTxnType((int)b[1]);
			 
			 dto.add(d);
		 }
			return dto;
		}

	 
}


