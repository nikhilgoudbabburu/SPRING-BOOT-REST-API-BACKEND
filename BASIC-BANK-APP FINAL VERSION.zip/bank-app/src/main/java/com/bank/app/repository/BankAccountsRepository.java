package com.bank.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bank.app.domain.BankAccounts;
import com.bank.app.domain.BankStatement;
import com.bank.app.dto.BankAccountsDto;


@Repository
public interface BankAccountsRepository extends JpaRepository<BankAccounts, Long> {

	BankAccountsDto save(BankAccountsDto bank);

	BankAccounts findByAcNum(String acNum);

	//DEPOSIT
	@Modifying
	@Query(value = "update bank_accounts set balance = balance + :amount where ac_num = :acNum",nativeQuery = true)
	int updateDeposit(
			@Param("amount") double amount,
			@Param("acNum") String acNum);
	
	//WITHDRAW
	@Modifying
	@Query(value = "update bank_accounts set balance = balance - :amount where ac_num = :acNum",nativeQuery = true)
	int updateWithdraw(
			@Param("amount") double amount,
			@Param("acNum") String acNum);

	//BALANCE  GREATER THAN
	@Query(value = "select * from bank_accounts where balance >= :balance",nativeQuery = true)
	List<BankAccounts> balancegreaterthan(@Param("balance") String balance);

	
}
