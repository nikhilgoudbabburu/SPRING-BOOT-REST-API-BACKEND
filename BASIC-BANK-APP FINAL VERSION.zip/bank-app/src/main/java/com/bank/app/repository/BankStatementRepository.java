package com.bank.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.bank.app.domain.BankStatement;
import com.bank.app.dto.TransactionTypeWiseDto;


@Repository
public interface BankStatementRepository extends JpaRepository<BankStatement, Long> {

	
	//TRANSACTION TYPE WISE
	@Query(value = "select sum(amount),txn_type from bank_statement where s_num = :acNum group by txn_type;",nativeQuery = true)
	List<Object[]> transactiontypeWise(@Param("acNum") String acNum);

	

}
