package com.bank.app.domain;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Entity
public class BankStatement {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column(nullable = false)
	private String sName;
	
	@Column(nullable = false)
	private String sNum;
	
	@Column
	private LocalDate txnDate;
	
	@Column
	private int txnType; //1=deposit 2 = withdraw 3 = transfer
	
	@Column
	private double amount;
	
	@Column
	private double sBalance;
}