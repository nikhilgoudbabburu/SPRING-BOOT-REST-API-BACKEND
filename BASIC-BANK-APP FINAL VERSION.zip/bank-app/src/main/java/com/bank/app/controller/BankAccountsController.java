package com.bank.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



import com.bank.app.dto.AppRes;
import com.bank.app.dto.BankAccountsDto;
import com.bank.app.service.BankAccountsService;
import com.bank.app.dto.CheckBalanceDto;



@RequestMapping("/accounts")
@RestController
public class BankAccountsController {

	@Autowired
	BankAccountsService service; 
	
	//CREATE ACCOUNT
	@PostMapping
	public  ResponseEntity<AppRes<Integer>> createAccount(@RequestBody BankAccountsDto bank){
		
		 	int op = service.openAccount(bank);
	        AppRes<Integer> res = new AppRes<>();
	        res.setRes(op);
	        res.setMsg("Saved Successfully");
	        res.setSts("success");
		
		 return new ResponseEntity<>( res, HttpStatus.CREATED);
	}
	
	//CHECK BALANCE
	@GetMapping("/balance/{acNum}")
	public ResponseEntity<AppRes<CheckBalanceDto>> checkBalance(@PathVariable String acNum){
		
		try {
			CheckBalanceDto bank = service.checkBalanceDto(acNum);
			AppRes<CheckBalanceDto> app =new AppRes<CheckBalanceDto>();
			
			app.setMsg("balanced checked successfull");
			
			app.setRes(bank);
			app.setSts("success");
			
			return ResponseEntity.ok(app);
		}catch(Exception exception)
		{
			AppRes<CheckBalanceDto> app =new AppRes<CheckBalanceDto>();
			
			app.setMsg("cannot find account number");
			
			app.setRes(null);
			app.setSts("fail");
			return new ResponseEntity<>(app,HttpStatus.BAD_REQUEST);
		}
		
	}
	
	//BALANCE ABOVE
	@GetMapping("/balanceabove/{balance}")
	public ResponseEntity<List<BankAccountsDto>> balanceAbove(@PathVariable String balance){
		
		List<BankAccountsDto> dto = service.balanceabove(balance);
		
		
		return ResponseEntity.ok(dto);
	
	}

	
	



	
}
