package com.bank.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.app.dto.AppRes;
import com.bank.app.dto.BankAccountsDto;
import com.bank.app.dto.TransactionTypeWiseDto;
import com.bank.app.service.BankStatementService;


@RequestMapping("/statement")
@RestController
public class BankStatementController {

	@Autowired
	BankStatementService service;
	
	
	//DEPOSIT and WITHDRAW
	@PostMapping("/{txnType}/{acNum}/{amount}/{date}") //
	public ResponseEntity<AppRes<Integer>> transaction(
			@PathVariable int txnType,
			@PathVariable String acNum, 
			@PathVariable double amount,
			@PathVariable String date
			){
		int op = service.transactionCheck(txnType,acNum,amount,date);
        AppRes<Integer> res = new AppRes<>();
        if(op == 1) {
        	res.setRes(op);
            res.setMsg("Saved Successfully");
            res.setSts("success");
        }else {
        	res.setRes(op);
            res.setMsg("WRONG DETAILS");
            res.setSts("FAILED");
            return new ResponseEntity<>( res, HttpStatus.BAD_REQUEST);
        }
	
	 return new ResponseEntity<>( res, HttpStatus.CREATED);
	}
	
	//MONEY TRANSFER
	
	@PostMapping("/transfer/{transfer}/{sender}/{receiver}/{amount}/{date}")
	public ResponseEntity<AppRes<Integer>> transfer(
			@PathVariable("transfer") int transfer,
			@PathVariable("sender") String sender,
			@PathVariable("receiver") String receiver,
			@PathVariable("amount") double amount,
			@PathVariable("date") String date
			){
		
		try {
			int bank = service.moneyTransfer(transfer,sender,receiver,amount,date);
			AppRes<Integer> app =new AppRes<Integer>();
			
			app.setMsg("Money Transfer successfull");
			
			app.setRes(bank);
			app.setSts("success");
			
			return ResponseEntity.ok(app);
			
		}catch(Exception exception)
		{
			AppRes<Integer> app =new AppRes<Integer>();
			
			app.setMsg("cannot find account number");
			
			app.setRes(null);
			app.setSts("fail");
			return new ResponseEntity<>(app,HttpStatus.BAD_REQUEST);
		}
		 
	}
	
	//TRANSACTION TYPE WISE
	@GetMapping("/ttypewise/{acNum}")
	public ResponseEntity<List<TransactionTypeWiseDto>> transactionTypeWise(@PathVariable("acNum") String acNum){
		
		List<TransactionTypeWiseDto> dto = service.transactiontypewise(acNum);
		
		return ResponseEntity.ok(dto);
		
	}
	
	
	

	
	
}
