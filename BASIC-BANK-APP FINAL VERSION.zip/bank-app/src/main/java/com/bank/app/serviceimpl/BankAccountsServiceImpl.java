package com.bank.app.serviceimpl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.app.domain.BankAccounts;
import com.bank.app.domain.BankStatement;
import com.bank.app.dto.BankAccountsDto;
import com.bank.app.dto.CheckBalanceDto;
import com.bank.app.repository.BankAccountsRepository;
import com.bank.app.service.BankAccountsService;

@Service
public class BankAccountsServiceImpl implements BankAccountsService{

	@Autowired
	BankAccountsRepository repository;
	
	//OPEN BANK ACCOUNT
	@Override
	public int openAccount(BankAccountsDto bank) {
		// TODO Auto-generated method stub
				BankAccounts ba =  new BankAccounts();
				ba.setUserId(bank.getUserId());
				ba.setAcName(bank.getAcName()); 
				ba.setAcNum(bank.getAcNum()); 
				ba.setBalance(bank.getBalance());
				ba.setCreated(LocalDate.now()); 
				
			
				repository.save(ba);
				
				return ba!= null ? 1 : 0;
	}


	//CHECK BALANCE

	@Override
	public CheckBalanceDto checkBalanceDto(String acNum) {
		// TODO Auto-generated method stub
		 BankAccounts bank = repository.findByAcNum(acNum);
		 double balance = bank.getBalance();
		 CheckBalanceDto dto = new CheckBalanceDto();
		 dto.setBalance(balance);
		 
		return dto;
	}



	//BALANCE ABOVE
	@Override
	public List<BankAccountsDto> balanceabove(String balance) {
		// TODO Auto-generated method stub
		
		List<BankAccounts> bank = repository.balancegreaterthan(balance);
		
		List<BankAccountsDto> dto = new ArrayList<>();
		
		for(int i = 0; i < bank.size();i++) {
			
			BankAccounts b = bank.get(i);
			
			BankAccountsDto d = new BankAccountsDto( );
			
			d.setUserId(b.getUserId());
			d.setAcName(b.getAcName());
			d.setAcNum(	b.getAcNum());
			d.setBalance(b.getBalance());
			d.setCreated(b.getCreated());
			dto.add(d);
		}
		
		return dto;
	}


	

}

